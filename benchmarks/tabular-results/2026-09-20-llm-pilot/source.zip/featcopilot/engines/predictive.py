"""Opt-in, inductive numeric feature discovery using residual screening.

The internal holdout selects a feature plan, not an unbiased performance estimate.
Only stateless arithmetic is retained for production; categorical columns and
missing values remain available to the downstream model's own preprocessing.
"""

from collections import deque
from collections.abc import Iterator
from copy import deepcopy
from dataclasses import dataclass
from itertools import combinations, islice
from typing import Any, Literal, Protocol, TypedDict, runtime_checkable

import numpy as np
import pandas as pd
from joblib import effective_n_jobs
from numpy.typing import ArrayLike
from pydantic import ConfigDict, Field, field_validator
from sklearn.base import clone, is_classifier, is_regressor
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import log_loss, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeRegressor
from threadpoolctl import threadpool_limits

from featcopilot.core.base import BaseEngine, EngineConfig
from featcopilot.core.feature import Feature, FeatureOrigin, FeatureSet, FeatureType
from featcopilot.engines.tabular import TabularEngine
from featcopilot.utils.logger import get_logger
from featcopilot.utils.splitting import (
    SplitMetadata,
    make_cv_splits,
    make_holdout_splits,
    validate_split_metadata,
)
from featcopilot.utils.task import resolve_task

logger = get_logger(__name__)

_SUBSET_SIZES = (1, 5, 10, 25, 50)
_MIN_RELATIVE_IMPROVEMENT = 0.001
_NUMERIC_LIMIT = 1e30
_NUMERIC_POLICY = "finite_clip_1e30_nonfinite_to_nan_v1"
_UNARY_EXPRESSIONS = {
    "square": "x**2",
    "log": "np.log1p(np.abs(x))",
    "sqrt": "np.sqrt(np.abs(x))",
    "cube": "x**3",
    "reciprocal": "1 / (x + 1e-8)",
    "tanh": "np.tanh(x)",
    "sin": "np.sin(x)",
    "cos": "np.cos(x)",
}


@runtime_checkable
class PredictiveEstimator(Protocol):
    """Cloneable numerical learner; inheriting sklearn BaseEstimator is not required."""

    def get_params(self, deep: bool = True) -> dict[str, object]:
        """Return sklearn-compatible constructor parameters."""
        ...

    def set_params(self, **params: object) -> "PredictiveEstimator":
        """Update parameters on an independent selection clone."""
        ...

    def fit(self, X: np.ndarray, y: np.ndarray, /) -> object:
        """Fit preprocessed numerical rows and a one-dimensional target."""
        ...

    def predict(self, X: np.ndarray, /) -> ArrayLike:
        """Predict from preprocessed numerical rows."""
        ...


def _clone_estimator(estimator: PredictiveEstimator) -> PredictiveEstimator:
    methods = ("get_params", "set_params", "fit", "predict")
    if not all(callable(getattr(estimator, name, None)) for name in methods):
        raise ValueError("estimator must implement callable get_params, set_params, fit and predict methods")
    try:
        cloned: object = clone(estimator)
    except (TypeError, ValueError, RuntimeError) as exc:
        raise ValueError(f"estimator must be cloneable with sklearn.base.clone: {exc}") from exc
    if (
        cloned is estimator
        or not isinstance(cloned, PredictiveEstimator)
        or not all(callable(getattr(cloned, name, None)) for name in methods)
    ):
        raise ValueError("sklearn.base.clone must return an independent estimator implementing the learner interface")
    return cloned


class SubsetValidationScore(TypedDict):
    """Repeated internal losses for a predeclared ranked prefix, including zero."""

    count: int
    loss: float
    loss_std: float
    loss_se: float
    losses: list[float]


class RepeatSelectionReport(TypedDict):
    """One internal boundary's training-only ranking and heldout comparisons."""

    repeat: int
    train_rows: int
    purged_train_rows: int
    validation_rows: int
    candidate_count: int
    screened_count: int
    candidate_ranking: list[str]
    candidate_scores: dict[str, float]
    baseline_loss: float
    validation_scores: list[SubsetValidationScore]
    selected_count: int
    screening_scored_rows: int
    screening_unscored_rows: int


class SelectionReport(TypedDict, total=False):
    """JSON-compatible diagnostics, empty until fitting succeeds."""

    task: str
    metric: str
    original_count: int
    numeric_count: int
    train_rows: int
    validation_rows: int
    candidate_count: int
    screened_count: int
    candidate_ranking: list[str]
    candidate_scores: dict[str, float]
    residual_cv_folds: int
    baseline_loss: float
    validation_scores: list[SubsetValidationScore]
    selected_count: int
    selected_features: list[str]
    internal_validation_only: bool
    numeric_policy: str
    stability_repeats: int
    screening: str
    split_kind: str
    selection_rule: str
    uncertainty_note: str
    baseline_loss_std: float
    baseline_loss_se: float
    baseline_losses: list[float]
    count_by_repeat: list[int]
    repeats: list[RepeatSelectionReport]
    ranking_scope: str
    ranking_scored_rows: int
    ranking_unscored_rows: int
    chronological_prefix_unscored: bool
    learner_fit_count: int
    label_end_times_supplied: bool
    label_availability_policy: str
    purged_train_rows_by_repeat: list[int]


@dataclass
class _ResidualFold:
    train: np.ndarray
    validation: np.ndarray
    train_residuals: np.ndarray
    validation_residuals: np.ndarray


@dataclass
class _Ranking:
    features: list[Feature]
    scores: dict[str, float]
    folds: int = 0
    scored_rows: int = 0
    unscored_rows: int = 0
    learner_fits: int = 0


@dataclass
class _Repeat:
    train: np.ndarray
    validation: np.ndarray
    candidates: list[Feature]
    numeric_count: int
    ranking: _Ranking
    losses: dict[int, float]


def _finite_clip(values: np.ndarray) -> np.ndarray:
    """Apply the generated-value policy, leaving missing/undefined results missing."""
    return np.clip(np.where(np.isfinite(values), values, np.nan), -_NUMERIC_LIMIT, _NUMERIC_LIMIT)


class PredictiveTabularEngineConfig(EngineConfig):
    """Validated configuration for opt-in predictive feature discovery."""

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="forbid")

    name: str = "PredictiveTabularEngine"
    max_features: int | None = Field(default=None, ge=0, description="Total output budget, retaining all originals")
    max_candidates: int = Field(default=1000, ge=0, le=1000, description="Maximum numeric candidates per repeat")
    task: Literal["auto", "classification", "regression"] = "auto"
    estimator: PredictiveEstimator | None = Field(
        default=None, description="Unfitted or fitted cloneable numerical learner with the sklearn parameter API"
    )
    random_state: int = Field(default=42, ge=0, le=2**32 - 1)
    n_jobs: int = Field(default=1, ge=-1, description="Worker and native-thread limit; -1 uses all available CPUs")
    stability_repeats: int = Field(default=3, ge=1, le=10, description="Number of internal selection boundaries")
    screening: Literal["auto", "tree", "linear"] = "auto"

    @field_validator("estimator")
    @classmethod
    def _validate_estimator(cls, value: PredictiveEstimator | None) -> PredictiveEstimator | None:
        if value is not None:
            _clone_estimator(value)
        return value

    @field_validator("n_jobs")
    @classmethod
    def _validate_n_jobs(cls, value: int) -> int:
        if value == 0:
            raise ValueError("n_jobs must be -1 or a positive integer")
        return value


class PredictiveTabularEngine(BaseEngine):
    """
    Select numeric features by incremental, training-only predictive signal.

    Candidate families are interleaved, not order-truncated by family. Each
    internal holdout has its own training-only candidate plan and ranking.
    Screening uses nested residual cross-fitting: no baseline producing a
    screening-training residual has seen that screening fold's test labels.
    Classification residuals are one-hot targets minus class probabilities.
    Counts 0, 1, 5, 10, 25 and 50 (clamped to the common available budget) compete
    on mean internal loss. The smallest count within one standard error of the
    best is preferred, requiring >0.1% relative improvement over originals.
    These overlapping internal splits give descriptive uncertainty, not an
    unbiased external performance estimate or confidence interval.

    Parameters
    ----------
    max_features : int or None, default=None
        Total output-column limit. All original columns are retained even when
        they already exceed this limit. At most 50 generated features are selected.
    max_candidates : int, default=1000
        Hard cap per repeat, at most 1000. Screening materializes one candidate
        at a time; subset evaluation materializes at most 50.
    task : {"auto", "classification", "regression"}, default="auto"
        Explicit overrides are recommended for integer-valued regression targets.
        Auto follows sklearn's binary/multiclass/continuous target convention.
    estimator : PredictiveEstimator or None, default=None
        Bare sklearn-compatible learner, accepting preprocessed numeric matrices.
        Requires callable ``get_params``, ``set_params``, ``fit`` and ``predict``
        methods and an independent sklearn clone, not BaseEstimator inheritance.
        It is cloned for every fit and never mutated. Classifiers must implement
        ``predict_proba``. Data-bound, fixed-column preprocessing is not supported.
        Defaults to the task-appropriate histogram gradient boosting estimator.
    random_state : int, default=42
        Seed for splits, screening trees and unspecified learner random states.
    n_jobs : int, default=1
        Positive limit for native thread pools and learner ``n_jobs`` parameters.
        Use -1 for all available CPUs, resolved through joblib for native thread
        limits. Candidate evaluation is sequential to bound memory.
    verbose : bool, default=False
        Log selection counts and losses.
    stability_repeats : int, default=3
        Number of independent seeded IID/group holdouts or disjoint forward
        validation windows, from 1 to 10. One retains single-holdout selection
        and its training-partition ranking. Multiple repeats refit the final
        ranking on all supplied training rows, using the first repeat's bounded
        candidate pool, after choosing the feature count.
    screening : {"auto", "tree", "linear"}, default="auto"
        Auto uses regularized linear residual screening for bare sklearn linear
        learners (including Ridge/LogisticRegression), shallow trees otherwise.
        Explicit choices support controlled ablations without changing learners.
    **kwargs : dict
        Additional base configuration, such as ``enabled``.

    Attributes
    ----------
    selection_report_ : dict
        JSON-compatible counts, ordered ``candidate_ranking``, training-only
        ``candidate_scores`` (cross-validated relative residual MSE reduction),
        ``baseline_loss``, ``validation_scores`` (including count zero, with
        ``loss``, ``loss_std``, ``loss_se`` and per-repeat ``losses``),
        ``selected_features``, ``selected_count``, ``task`` and ``metric``.
        ``repeats`` contains each boundary's training-only ranking, losses and
        scored/unscored row counts; ``count_by_repeat`` exposes count instability.
        ``baseline_loss`` is the mean across repeats, not the final refit's score.
        ``numeric_policy``, ``screening``, ``split_kind`` and ``ranking_scope``
        identify the representation and protocol. With the default three repeats
        there are at most 42 learner fits, plus bounded candidate-screening fits.
        ``label_end_times_supplied``, ``label_availability_policy`` and
        ``purged_train_rows_by_repeat`` describe label-availability handling.
        ``internal_validation_only`` is always true. No data, labels, indices,
        fitted preprocessors or fitted selection learners are retained.

    Notes
    -----
    Originals, including categorical columns, retain their values and dtypes.
    Generated infinities and undefined arithmetic become NaN, never batch-fitted
    imputations. Internal numeric preprocessing uses train-fitted median
    imputation and standard scaling; categoricals use constant missing-value
    imputation and train-fitted OHE with unknown categories ignored. Generated
    finite outputs are clipped to +/-1e30 in every stage, including exported code;
    overflowing arithmetic becomes NaN. Original values are never changed by
    transform. The internal learner's numeric preprocessing also bounds its
    original-column inputs for float32-based learner safety.
    Columns must have unique string names. Transform accepts reordered columns,
    but rejects missing/extra columns and returns the fitted output-column order.
    Products and differences use canonical column order; ratios include both
    directions. Reverse differences are omitted as exact sign aliases.
    """

    def __init__(
        self,
        max_features: int | None = None,
        max_candidates: int = 1000,
        task: str = "auto",
        estimator: PredictiveEstimator | None = None,
        random_state: int = 42,
        n_jobs: int = 1,
        verbose: bool = False,
        stability_repeats: int = 3,
        screening: str = "auto",
        **kwargs: Any,
    ):
        config = PredictiveTabularEngineConfig.model_validate(
            {
                **kwargs,
                "max_features": max_features,
                "max_candidates": max_candidates,
                "task": task,
                "estimator": estimator,
                "random_state": random_state,
                "n_jobs": n_jobs,
                "verbose": verbose,
                "stability_repeats": stability_repeats,
                "screening": screening,
            }
        )
        super().__init__(config=config)
        self.config: PredictiveTabularEngineConfig = config
        self._reset()

    def _reset(self) -> None:
        self._is_fitted = False
        self._feature_names = []
        self._feature_metadata = {}
        self._input_columns: list[str] = []
        self._numeric_columns: list[str] = []
        self._selected_features: list[Feature] = []
        self._feature_set = FeatureSet()
        self.selection_report_: SelectionReport = {}

    def fit(
        self,
        X: pd.DataFrame | np.ndarray,
        y: pd.Series | np.ndarray | None = None,
        *,
        groups: ArrayLike | None = None,
        timestamps: ArrayLike | None = None,
        label_end_times: ArrayLike | None = None,
        **kwargs: Any,
    ) -> "PredictiveTabularEngine":
        """
        Fit a stateless feature plan using training-only internal boundaries.

        Parameters
        ----------
        X : DataFrame or ndarray
            Original mixed features with at least eight rows.
        y : Series or ndarray
            Required one-dimensional, nonconstant target, aligned positionally.
        groups : array-like or None, default=None
            Positionally aligned entity labels. Every holdout and nested residual
            fold keeps entities disjoint. Numeric screening needs at least four
            training groups in each holdout (normally six groups overall), with
            class coverage inside each training partition.
        timestamps : array-like or None, default=None
            Positionally aligned finite numeric or datetime timestamps. Equal
            timestamps stay together and every validation block is strictly
            after its training prefix. Numeric screening needs at least six
            training time blocks per holdout (twelve overall with three repeats).
            The first prefix has no OOF residual and is explicitly
            unscored. Groups and timestamps together are not supported.
        label_end_times : array-like or None, default=None
            Positionally aligned label-availability times, requiring timestamps
            in the same numeric units or datetime domain. End times must be at
            least prediction timestamps. At EVERY holdout and nested residual
            fold, training labels must be available strictly before the earliest
            validation timestamp. Purged rows are not moved into validation.
            No random fallback is used if insufficient labeled history remains.
        **kwargs : dict
            Reserved; unsupported arguments raise TypeError rather than being
            silently ignored. Sample weights and external validation sets are
            not currently accepted.

        Returns
        -------
        self : PredictiveTabularEngine
            Fitted engine with selected feature metadata and selection report.

        Raises
        ------
        ValueError
            If targets, schema, generated names or the internal split are invalid.
        TypeError
            If input types or additional fit arguments are unsupported.
        """
        self._reset()
        if kwargs:
            raise TypeError(f"Unsupported fit arguments: {sorted(kwargs)}")
        X = self._validate_frame(X)
        target, task = self._validate_target(y, len(X))
        boundaries = self._validate_boundaries(groups, timestamps, len(X), label_end_times=label_end_times)
        self._input_columns = X.columns.tolist()
        self._numeric_columns = sorted(column for column in X.columns if pd.api.types.is_numeric_dtype(X[column].dtype))
        n_classes = 0
        if task == "classification":
            encoder = LabelEncoder().fit(target)
            target = encoder.transform(target)
            n_classes = len(encoder.classes_)

        budget = _SUBSET_SIZES[-1]
        if self.config.max_features is not None:
            budget = min(budget, max(0, self.config.max_features - len(self._input_columns)))
        partitions = self._holdouts(target, task, boundaries)
        template = self._learner(task)
        screening = self._resolve_screening(template)
        repeats: list[_Repeat] = []
        learner_fits = 0

        with threadpool_limits(limits=effective_n_jobs(self.config.n_jobs)):
            for repeat_index, (train_indices, validation_indices) in enumerate(partitions):
                train = X.iloc[train_indices]
                candidates, numeric_count = self._plan_candidates(train, budget)
                ranking = self._rank_candidates(
                    candidates,
                    train,
                    self._model_frame(train),
                    target[train_indices],
                    template,
                    task,
                    n_classes,
                    boundaries=boundaries.subset(train_indices),
                    seed=self._seed(repeat_index),
                    screening=screening,
                )
                learner_fits += ranking.learner_fits
                repeats.append(_Repeat(train_indices, validation_indices, candidates, numeric_count, ranking, {}))

            common_budget = min(budget, *(len(repeat.ranking.features) for repeat in repeats))
            sizes = sorted({0, *(min(size, common_budget) for size in _SUBSET_SIZES)})
            for repeat in repeats:
                train = X.iloc[repeat.train]
                validation = X.iloc[repeat.validation]
                prepared_train = self._model_frame(train)
                prepared_validation = self._model_frame(validation)
                for size in sizes:
                    features = repeat.ranking.features[:size]
                    augmented_train = self._augment(prepared_train, train, features) if size else prepared_train
                    augmented_validation = (
                        self._augment(prepared_validation, validation, features) if size else prepared_validation
                    )
                    learner = self._fit_learner(augmented_train, target[repeat.train], template)
                    learner_fits += 1
                    repeat.losses[size] = self._loss(
                        learner, augmented_validation, target[repeat.validation], task, n_classes
                    )

            validation_scores = [
                self._summarize_losses(size, [repeat.losses[size] for repeat in repeats]) for size in sizes
            ]
            selected_count = self._choose_count(validation_scores)
            final_ranking = repeats[0].ranking
            if self.config.stability_repeats > 1:
                final_ranking = self._rank_candidates(
                    repeats[0].candidates,
                    X,
                    self._model_frame(X),
                    target,
                    template,
                    task,
                    n_classes,
                    boundaries=boundaries,
                    seed=self._seed(self.config.stability_repeats),
                    screening=screening,
                )
                learner_fits += final_ranking.learner_fits
            if len(final_ranking.features) < selected_count:
                raise ValueError("Final training ranking cannot supply the validated feature count")

        self._selected_features = final_ranking.features[:selected_count]
        self._feature_names = [feature.name for feature in self._selected_features]
        self._feature_set = FeatureSet(self._selected_features)
        self._feature_metadata = deepcopy({feature.name: feature.to_dict() for feature in self._selected_features})
        repeat_reports: list[RepeatSelectionReport] = []
        for index, repeat in enumerate(repeats):
            repeat_scores = [self._summarize_losses(size, [repeat.losses[size]]) for size in sizes]
            purged_train_rows = 0
            if boundaries.label_end_times is not None and boundaries.values is not None:
                cutoff = boundaries.values[repeat.validation].min()
                purged_train_rows = int(np.count_nonzero(boundaries.values < cutoff)) - len(repeat.train)
            repeat_reports.append(
                {
                    "repeat": index,
                    "train_rows": len(repeat.train),
                    "purged_train_rows": purged_train_rows,
                    "validation_rows": len(repeat.validation),
                    "candidate_count": len(repeat.candidates),
                    "screened_count": len(repeat.ranking.features),
                    "candidate_ranking": [feature.name for feature in repeat.ranking.features],
                    "candidate_scores": repeat.ranking.scores,
                    "baseline_loss": repeat.losses[0],
                    "validation_scores": repeat_scores,
                    "selected_count": self._choose_count(repeat_scores),
                    "screening_scored_rows": repeat.ranking.scored_rows,
                    "screening_unscored_rows": repeat.ranking.unscored_rows,
                }
            )
        baseline_summary = validation_scores[0]
        self.selection_report_ = {
            "task": task,
            "metric": "log_loss" if task == "classification" else "rmse",
            "original_count": len(self._input_columns),
            "numeric_count": repeats[0].numeric_count,
            "train_rows": len(repeats[0].train),
            "validation_rows": len(repeats[0].validation),
            "candidate_count": len(repeats[0].candidates),
            "screened_count": len(final_ranking.features),
            "candidate_ranking": [feature.name for feature in final_ranking.features],
            "candidate_scores": final_ranking.scores,
            "residual_cv_folds": final_ranking.folds,
            "baseline_loss": baseline_summary["loss"],
            "validation_scores": validation_scores,
            "selected_count": selected_count,
            "selected_features": self._feature_names.copy(),
            "internal_validation_only": True,
            "numeric_policy": _NUMERIC_POLICY,
            "stability_repeats": self.config.stability_repeats,
            "screening": screening,
            "split_kind": boundaries.kind,
            "selection_rule": "smallest_within_one_se_and_0.1pct_relative_gain",
            "uncertainty_note": "Descriptive across overlapping internal training splits; not a confidence interval.",
            "baseline_loss_std": baseline_summary["loss_std"],
            "baseline_loss_se": baseline_summary["loss_se"],
            "baseline_losses": baseline_summary["losses"],
            "count_by_repeat": [report["selected_count"] for report in repeat_reports],
            "repeats": repeat_reports,
            "ranking_scope": (
                "single_holdout_train" if self.config.stability_repeats == 1 else "all_fit_rows_first_repeat_candidates"
            ),
            "ranking_scored_rows": final_ranking.scored_rows,
            "ranking_unscored_rows": final_ranking.unscored_rows,
            "chronological_prefix_unscored": boundaries.kind == "temporal",
            "learner_fit_count": learner_fits,
            "label_end_times_supplied": boundaries.label_end_times is not None,
            "label_availability_policy": (
                "strictly_before_validation_start" if boundaries.label_end_times is not None else "not_requested"
            ),
            "purged_train_rows_by_repeat": [report["purged_train_rows"] for report in repeat_reports],
        }
        self._is_fitted = True
        if self.config.verbose:
            logger.info(
                "PredictiveTabularEngine: selected %d/%d candidates; internal %s %.6g -> %.6g",
                selected_count,
                len(repeats[0].candidates),
                self.selection_report_["metric"],
                baseline_summary["loss"],
                next(score["loss"] for score in validation_scores if score["count"] == selected_count),
            )
        return self

    def fit_transform(
        self,
        X: pd.DataFrame | np.ndarray,
        y: pd.Series | np.ndarray | None = None,
        *,
        groups: ArrayLike | None = None,
        timestamps: ArrayLike | None = None,
        label_end_times: ArrayLike | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Fit with positional boundary metadata and transform without reusing it."""
        self.fit(X, y, groups=groups, timestamps=timestamps, label_end_times=label_end_times, **kwargs)
        return self.transform(X)

    def transform(self, X: pd.DataFrame | np.ndarray, **kwargs: Any) -> pd.DataFrame:
        """
        Return original columns plus selected, batch-invariant numeric features.

        Parameters
        ----------
        X : DataFrame or ndarray
            Rows with the fitted input schema, optionally reordered.
        **kwargs : dict
            Reserved; unsupported arguments raise TypeError.

        Returns
        -------
        DataFrame
            Exact input index, original values/dtypes in fitted order, then
            selected float columns. Missing generated values are not imputed.
        """
        if not self._is_fitted:
            raise RuntimeError("Engine must be fitted before transform")
        if kwargs:
            raise TypeError(f"Unsupported transform arguments: {sorted(kwargs)}")
        X = self._validate_frame(X)
        if set(X.columns) != set(self._input_columns):
            missing = sorted(set(self._input_columns) - set(X.columns))
            extra = sorted(set(X.columns) - set(self._input_columns))
            raise ValueError(f"Input schema differs from fit: missing={missing}, extra={extra}")
        for column in self._numeric_columns:
            if not pd.api.types.is_numeric_dtype(X[column].dtype):
                raise TypeError(f"Column {column!r} must remain numeric at transform time")
        result = X.loc[:, self._input_columns].copy()
        generated = {feature.name: self._compute(feature, X) for feature in self._selected_features}
        if generated:
            result = pd.concat([result, pd.DataFrame(generated, index=X.index)], axis=1)
            result.columns.name = X.columns.name
        return result

    def get_feature_set(self) -> FeatureSet:
        """Get a defensive copy of selected generated-feature metadata."""
        return deepcopy(self._feature_set)

    def _validate_frame(self, X: pd.DataFrame | np.ndarray) -> pd.DataFrame:
        if isinstance(X, np.ndarray) and X.ndim != 2:
            raise ValueError("X must be a two-dimensional array")
        frame = self._validate_input(X)
        if not frame.columns.is_unique:
            raise ValueError("X must have unique column names")
        if not all(isinstance(column, str) for column in frame.columns):
            raise ValueError("X column names must be strings")
        if len(frame.columns) == 0:
            raise ValueError("X must contain at least one original feature")
        if any(pd.api.types.is_complex_dtype(dtype) for dtype in frame.dtypes):
            raise TypeError("Complex numeric columns are not supported")
        return frame

    def _validate_target(self, y: pd.Series | np.ndarray | None, n_rows: int) -> tuple[np.ndarray, str]:
        if y is None:
            raise ValueError("y is required to fit predictive feature selection")
        target = np.asarray(y)
        if target.ndim != 1:
            raise ValueError(f"y must be one-dimensional, got shape {target.shape}")
        if len(target) != n_rows:
            raise ValueError("X and y must contain the same number of rows")
        if pd.isna(target).any():
            raise ValueError("y must not contain missing values")
        target = pd.Series(target).infer_objects().to_numpy()
        if pd.api.types.is_complex_dtype(target.dtype):
            raise ValueError("Complex targets are not supported; y must contain real numbers or class labels")
        if pd.api.types.is_numeric_dtype(target.dtype) and not np.isfinite(target).all():
            raise ValueError("y must contain only finite values")
        if pd.Series(target).nunique() < 2:
            raise ValueError("y must not be constant")
        task = resolve_task(target, self.config.task)
        return target.astype(float) if task == "regression" else target, task

    _validate_boundaries = staticmethod(validate_split_metadata)

    def _seed(self, offset: int) -> int:
        return (self.config.random_state + offset) % (2**32)

    def _holdouts(
        self, target: np.ndarray, task: str, boundaries: SplitMetadata
    ) -> list[tuple[np.ndarray, np.ndarray]]:
        if len(target) < 8:
            raise ValueError("At least 8 samples are required for internal holdout selection")
        return make_holdout_splits(
            target,
            task,
            self.config.stability_repeats,
            self.config.random_state,
            groups=boundaries.groups,
            timestamps=boundaries.timestamps,
            label_end_times=boundaries.label_end_times,
            allow_constant_target=False,
        )

    def _cv_splits(
        self,
        target: np.ndarray,
        task: str,
        boundaries: SplitMetadata,
        n_splits: int,
        seed: int,
    ) -> list[tuple[np.ndarray, np.ndarray]]:
        return make_cv_splits(
            target,
            task,
            n_splits,
            seed,
            groups=boundaries.groups,
            timestamps=boundaries.timestamps,
            label_end_times=boundaries.label_end_times,
            allow_constant_target=False,
        )

    @staticmethod
    def _summarize_losses(count: int, losses: list[float]) -> SubsetValidationScore:
        values = np.asarray(losses)
        scale = float(np.max(np.abs(values)))
        normalized = values / scale if scale else values
        mean = float(normalized.mean()) * scale
        std = float(normalized.std(ddof=1)) * scale if len(values) > 1 else 0.0
        return {"count": count, "loss": mean, "loss_std": std, "loss_se": std / np.sqrt(len(values)), "losses": losses}

    @staticmethod
    def _choose_count(scores: list[SubsetValidationScore]) -> int:
        baseline = next(score["loss"] for score in scores if score["count"] == 0)
        best = min(scores, key=lambda score: (score["loss"], score["count"]))
        threshold = best["loss"] + max(best["loss_se"], best["loss"] * _MIN_RELATIVE_IMPROVEMENT)
        if baseline <= threshold:
            return 0
        eligible = [
            score["count"]
            for score in scores
            if score["loss"] <= threshold and score["loss"] < baseline * (1 - _MIN_RELATIVE_IMPROVEMENT)
        ]
        return min(eligible, default=0)

    def _resolve_screening(self, learner: PredictiveEstimator) -> str:
        if self.config.screening != "auto":
            return self.config.screening
        linear = any(cls.__module__.startswith("sklearn.linear_model.") for cls in type(learner).__mro__)
        return "linear" if linear else "tree"

    def _plan_candidates(self, train: pd.DataFrame, budget: int) -> tuple[list[Feature], int]:
        unique = {column: pd.Series(self._values(train[column])).nunique() for column in self._numeric_columns}
        eligible = [column for column, count in unique.items() if count > 1]
        continuous = [column for column, count in unique.items() if count > 2]
        candidates = (
            list(islice(self._candidate_stream(eligible, continuous), self.config.max_candidates)) if budget else []
        )
        self._check_collisions(candidates)
        return candidates, len(eligible)

    @staticmethod
    def _values(column: pd.Series) -> np.ndarray:
        values = column.to_numpy(dtype=float, na_value=np.nan)
        return np.where(np.isfinite(values), values, np.nan)

    def _model_frame(self, frame: pd.DataFrame) -> pd.DataFrame:
        columns: dict[str, Any] = {}
        for column in sorted(frame.columns):
            series = frame[column]
            if pd.api.types.is_numeric_dtype(series.dtype):
                columns[column] = _finite_clip(self._values(series))
            else:
                # Prefixing values distinguishes e.g. integer 1 from string "1"
                # and reserves the unprefixed imputer sentinel for missingness.
                columns[column] = series.astype(object).map(
                    lambda value: np.nan if pd.isna(value) else f"{type(value).__name__}:{value}"
                )
        return pd.DataFrame(columns, index=frame.index)

    def _learner(self, task: str) -> PredictiveEstimator:
        if self.config.estimator is None:
            cls = HistGradientBoostingClassifier if task == "classification" else HistGradientBoostingRegressor
            default_learner: PredictiveEstimator = cls(
                max_iter=100, max_leaf_nodes=15, early_stopping=False, random_state=self.config.random_state
            )
            return default_learner
        learner = _clone_estimator(self.config.estimator)
        if (task == "classification" and is_regressor(learner)) or (task == "regression" and is_classifier(learner)):
            raise ValueError(f"The injected estimator is incompatible with task={task!r}")
        if task == "classification" and not callable(getattr(learner, "predict_proba", None)):
            raise ValueError("Classification estimators must implement predict_proba")
        parameters = learner.get_params(deep=True)
        overrides = {
            name: self.config.n_jobs
            for name, value in parameters.items()
            if (name == "n_jobs" or name.endswith("__n_jobs")) and (value is not None or self.config.n_jobs != 1)
        }
        overrides.update(
            {
                name: self.config.random_state
                for name, value in parameters.items()
                if (name == "random_state" or name.endswith("__random_state")) and value is None
            }
        )
        learner.set_params(**overrides)
        return learner

    @staticmethod
    def _fit_learner(frame: pd.DataFrame, target: np.ndarray, template: PredictiveEstimator) -> Pipeline:
        numeric = [
            column
            for column in frame.columns
            if pd.api.types.is_numeric_dtype(frame[column].dtype) and frame[column].notna().any()
        ]
        categorical = [column for column in frame.columns if not pd.api.types.is_numeric_dtype(frame[column].dtype)]
        transformers: list[tuple[str, Pipeline, list[str]]] = []
        if numeric:
            transformers.append(
                (
                    "numeric",
                    Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]),
                    numeric,
                )
            )
        if categorical:
            encoder_options: dict[str, Any] = {"handle_unknown": "ignore"}
            sparse_parameter = "sparse_output" if "sparse_output" in OneHotEncoder().get_params() else "sparse"
            encoder_options[sparse_parameter] = False
            imputer_options: dict[str, Any] = {"strategy": "constant", "fill_value": "__missing__"}
            if "keep_empty_features" in SimpleImputer().get_params():
                imputer_options["keep_empty_features"] = True
            transformers.append(
                (
                    "categorical",
                    Pipeline(
                        [
                            ("imputer", SimpleImputer(**imputer_options)),
                            ("onehot", OneHotEncoder(**encoder_options)),
                        ]
                    ),
                    categorical,
                )
            )
        if not transformers:
            raise ValueError("Internal training split contains no finite numeric or categorical baseline features")
        pipeline = Pipeline(
            [
                ("preprocess", ColumnTransformer(transformers, sparse_threshold=0.0)),
                ("learner", _clone_estimator(template)),
            ]
        )
        pipeline.fit(frame, target)
        return pipeline

    def _candidate_stream(self, eligible: list[str], continuous: list[str]) -> Iterator[Feature]:
        families = deque(
            [
                self._unary_family(continuous, "square"),
                self._pair_family(eligible, "multiply"),
                self._pair_family(eligible, "subtract"),
                self._pair_family(eligible, "divide"),
                self._pair_family(eligible, "divide", reverse=True),
                *(
                    self._unary_family(continuous, operation)
                    for operation in _UNARY_EXPRESSIONS
                    if operation != "square"
                ),
            ]
        )
        while families:
            family = families.popleft()
            feature = next(family, None)
            if feature is not None:
                families.append(family)
                yield feature

    def _unary_family(self, columns: list[str], operation: str) -> Iterator[Feature]:
        suffix = TabularEngine.TRANSFORMATIONS[operation][0]
        for column in columns:
            yield self._feature(f"{column}_{suffix}", [column], operation, _UNARY_EXPRESSIONS[operation])

    def _pair_family(self, columns: list[str], operation: str, reverse: bool = False) -> Iterator[Feature]:
        suffix, expression = {
            "multiply": ("x", "x * z"),
            "subtract": ("minus", "x - z"),
            "divide": ("div", "np.divide(x, z, out=np.full_like(x, np.nan), where=z != 0)"),
        }[operation]
        for left, right in combinations(columns, 2):
            if reverse:
                left, right = right, left
            yield self._feature(f"{left}_{suffix}_{right}", [left, right], operation, expression)

    @staticmethod
    def _feature(name: str, columns: list[str], operation: str, expression: str) -> Feature:
        code = []
        for variable, column in zip(("x", "z"), columns, strict=False):
            code.extend(
                [
                    f"{variable} = df[{column!r}].to_numpy(dtype=float, na_value=np.nan)",
                    f"{variable} = np.where(np.isfinite({variable}), {variable}, np.nan)",
                ]
            )
        code.extend(
            [
                'with np.errstate(divide="ignore", invalid="ignore", over="ignore"):',
                f"    values = {expression}",
                f"result = pd.Series(np.clip(np.where(np.isfinite(values), values, np.nan), "
                f"{-_NUMERIC_LIMIT!r}, {_NUMERIC_LIMIT!r}), index=df.index)",
            ]
        )
        origin = FeatureOrigin.INTERACTION if len(columns) == 2 else FeatureOrigin.CUSTOM
        if operation in {"square", "cube"}:
            origin = FeatureOrigin.POLYNOMIAL
        return Feature(
            name=name,
            dtype=FeatureType.NUMERIC,
            origin=origin,
            source_columns=columns,
            transformation=operation,
            explanation=f"{operation} of {', '.join(columns)}; selected by internal residual screening and holdout loss",
            code="\n".join(code),
            metadata={"numeric_policy": _NUMERIC_POLICY},
        )

    def _check_collisions(self, candidates: list[Feature]) -> None:
        names = set(self._input_columns)
        for feature in candidates:
            if feature.name in names:
                raise ValueError(f"Generated-name collision for {feature.name!r}; rename the conflicting input columns")
            names.add(feature.name)

    def _compute(self, feature: Feature, frame: pd.DataFrame) -> np.ndarray:
        left = self._values(frame[feature.source_columns[0]])
        operation = feature.transformation
        with np.errstate(divide="ignore", invalid="ignore", over="ignore"):
            if len(feature.source_columns) == 1:
                values = TabularEngine.TRANSFORMATIONS[operation][1](left)
            else:
                right = self._values(frame[feature.source_columns[1]])
                if operation == "multiply":
                    values = left * right
                elif operation == "subtract":
                    values = left - right
                elif operation == "divide":
                    values = np.divide(left, right, out=np.full_like(left, np.nan), where=right != 0)
                else:
                    raise ValueError(f"Unknown feature operation: {operation!r}")
        return _finite_clip(values)

    def _augment(self, prepared: pd.DataFrame, raw: pd.DataFrame, features: list[Feature]) -> pd.DataFrame:
        generated = {feature.name: self._compute(feature, raw) for feature in features}
        return pd.concat([prepared, pd.DataFrame(generated, index=raw.index)], axis=1)

    @staticmethod
    def _prediction(model: Pipeline, frame: pd.DataFrame, task: str, n_classes: int) -> np.ndarray:
        if task == "regression":
            prediction = np.asarray(model.predict(frame), dtype=float)
            if prediction.shape != (len(frame),) or not np.isfinite(prediction).all():
                raise ValueError("Regression estimator must return finite one-dimensional predictions")
            return prediction
        probabilities = np.asarray(model.predict_proba(frame), dtype=float)
        classes = np.asarray(model.classes_)
        if (
            probabilities.shape != (len(frame), n_classes)
            or set(classes) != set(range(n_classes))
            or not np.isfinite(probabilities).all()
            or (probabilities < 0).any()
            or not np.allclose(probabilities.sum(axis=1), 1.0)
        ):
            raise ValueError("Classifier predict_proba must return finite probabilities for every training class")
        return probabilities[:, np.argsort(classes)]

    def _loss(self, model: Pipeline, frame: pd.DataFrame, target: np.ndarray, task: str, n_classes: int) -> float:
        prediction = self._prediction(model, frame, task, n_classes)
        loss = (
            float(log_loss(target, prediction, labels=np.arange(n_classes)))
            if task == "classification"
            else float(np.sqrt(mean_squared_error(target, prediction)))
        )
        if not np.isfinite(loss):
            raise ValueError("The internal validation loss is not finite; check target scale and learner predictions")
        return loss

    def _rank_candidates(
        self,
        candidates: list[Feature],
        raw: pd.DataFrame,
        prepared: pd.DataFrame,
        target: np.ndarray,
        template: PredictiveEstimator,
        task: str,
        n_classes: int,
        *,
        boundaries: SplitMetadata | None = None,
        seed: int | None = None,
        screening: str | None = None,
    ) -> _Ranking:
        if not candidates:
            return _Ranking([], {}, unscored_rows=len(raw))
        boundaries = boundaries or SplitMetadata()
        seed = self.config.random_state if seed is None else seed
        screening = screening or self._resolve_screening(template)
        if boundaries.values is not None:
            count = len(np.unique(boundaries.values))
            if boundaries.kind == "grouped" and count < 4:
                raise ValueError(
                    "Grouped residual screening needs at least four training groups; "
                    "provide at least six groups before the holdout"
                )
            if boundaries.kind == "temporal" and count < 6:
                raise ValueError(
                    "Temporal residual screening needs at least six training time blocks; "
                    "provide at least twelve time blocks for repeated holdouts"
                )
        folds, learner_fits = self._residual_folds(prepared, target, template, task, n_classes, boundaries, seed)
        reference_error = sum(
            float(np.square(fold.validation_residuals - fold.train_residuals.mean(axis=0)).sum()) for fold in folds
        )
        if not np.isfinite(reference_error):
            raise ValueError("Residual screening loss is not finite; rescale the target or check the estimator")
        scores: dict[str, float] = {}
        for feature in candidates:
            values = self._compute(feature, raw)
            if pd.Series(values).nunique() < 2:
                continue
            error = 0.0
            for fold in folds:
                prediction = self._screen_prediction(
                    values[fold.train], values[fold.validation], fold.train_residuals, screening, seed
                )
                error += float(np.square(fold.validation_residuals - prediction).sum())
            if not np.isfinite(error):
                raise ValueError(f"Residual screening loss is not finite for candidate {feature.name!r}")
            scores[feature.name] = float((reference_error - error) / max(reference_error, np.finfo(float).eps))
        ranked = sorted(
            (feature for feature in candidates if feature.name in scores),
            key=lambda feature: (-scores[feature.name], feature.name),
        )
        for feature in ranked:
            feature.importance = scores[feature.name]
        scored_rows = sum(len(fold.validation) for fold in folds)
        return _Ranking(
            ranked,
            {feature.name: scores[feature.name] for feature in ranked},
            len(folds),
            scored_rows,
            len(raw) - scored_rows,
            learner_fits,
        )

    def _residual_folds(
        self,
        prepared: pd.DataFrame,
        target: np.ndarray,
        template: PredictiveEstimator,
        task: str,
        n_classes: int,
        boundaries: SplitMetadata,
        seed: int,
    ) -> tuple[list[_ResidualFold], int]:
        splits = self._cv_splits(target, task, boundaries, n_splits=3, seed=seed)
        observed = (
            np.eye(n_classes)[target.astype(int)] if task == "classification" else target.astype(float).reshape(-1, 1)
        )
        folds: list[_ResidualFold] = []
        learner_fits = 0
        for index, (train, validation) in enumerate(splits):
            residuals = np.full((len(train), observed.shape[1]), np.nan)
            scored = np.zeros(len(train), dtype=bool)
            validation_prediction = np.zeros((len(validation), observed.shape[1]))
            inner = self._cv_splits(
                target[train],
                task,
                boundaries.subset(train),
                n_splits=2,
                seed=(seed + index + 1) % (2**32),
            )
            # These baseline fits are entirely inside the screening-training
            # partition; none can depend on screening-validation labels.
            for inner_train, inner_validation in inner:
                fit_rows = train[inner_train]
                score_rows = train[inner_validation]
                baseline = self._fit_learner(prepared.iloc[fit_rows], target[fit_rows], template)
                learner_fits += 1
                prediction = self._prediction(baseline, prepared.iloc[score_rows], task, n_classes)
                residuals[inner_validation] = observed[score_rows] - prediction.reshape(len(score_rows), -1)
                scored[inner_validation] = True
                prediction = self._prediction(baseline, prepared.iloc[validation], task, n_classes)
                validation_prediction += prediction.reshape(len(validation), -1) / len(inner)
            if scored.sum() < 2:
                raise ValueError(
                    "Nested residual screening needs at least two scored training rows after the unscored "
                    "chronological prefix; provide more time blocks or samples"
                )
            # Reuse the inner learners instead of a larger full-training learner:
            # otherwise training and validation residuals differ in model capacity.
            validation_residuals = observed[validation] - validation_prediction
            folds.append(_ResidualFold(train[scored], validation, residuals[scored], validation_residuals))
        return folds, learner_fits

    @staticmethod
    def _screen_prediction(
        train_values: np.ndarray,
        validation_values: np.ndarray,
        residuals: np.ndarray,
        screening: str,
        seed: int,
    ) -> np.ndarray:
        finite = train_values[np.isfinite(train_values)]
        median = float(np.median(finite)) if len(finite) else 0.0
        train = np.where(np.isfinite(train_values), train_values, median)
        validation = np.where(np.isfinite(validation_values), validation_values, median)
        if screening == "linear":
            center = float(train.mean())
            scale = float(train.std()) or 1.0
            normalized = (train - center) / scale
            intercept = residuals.mean(axis=0)
            # A fixed unit ridge penalty on train-standardized values prevents
            # fitting a perfect slope to tiny/near-constant screening samples.
            coefficient = normalized @ (residuals - intercept) / (float(normalized @ normalized) + 1.0)
            return np.asarray(intercept + ((validation - center) / scale)[:, None] * coefficient)
        if screening != "tree":
            raise ValueError(f"Unknown residual screening method: {screening!r}")
        tree = DecisionTreeRegressor(
            max_depth=3,
            min_samples_leaf=max(2, min(20, len(train) // 20)),
            random_state=seed,
        )
        tree.fit(train.reshape(-1, 1), residuals)
        return np.asarray(tree.predict(validation.reshape(-1, 1))).reshape(len(validation), -1)
