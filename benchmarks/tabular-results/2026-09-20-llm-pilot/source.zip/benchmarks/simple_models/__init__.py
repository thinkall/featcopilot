"""Simple models benchmark module."""
