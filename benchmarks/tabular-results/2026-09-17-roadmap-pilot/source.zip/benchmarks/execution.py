"""Catalog-backed, per-learner benchmark execution and exact resume."""

from __future__ import annotations

import importlib.metadata
import json
import logging
import pickle
import platform
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

from benchmarks.run_state import (
    ExposureLedger,
    ResumeMismatchError,
    RunState,
    archive_results,
    archive_source,
    atomic_json,
    fingerprint,
)

logger = logging.getLogger(__name__)
DEFAULTS: dict[str, Any] = {
    "datasets": None,
    "folds": 3,
    "seeds": [42, 137],
    "max_rows": 5000,
    "max_added_features": 50,
    "max_candidates": 1000,
    "threads": 2,
    "memory_limit_mb": 4096,
    "case_timeout": 120.0,
    "synthetic": False,
    "stability_repeats": 3,
    "screening": "auto",
    "allow_confirmation": False,
    "detailed_diagnostics": False,
}
LEGACY_FAMILIES = {
    "magic": "magic-telescope",
    "bank": "bank-marketing",
    "credit": "give-me-some-credit",
    "heloc": "heloc",
    "credit_default": "default-of-credit-card-clients",
    "eye_movements": "eye-movements",
    "cpu": "cpu-act",
    "wine": "wine-quality",
    "houses": "california-housing",
    "elevators": "elevators",
    "abalone": "abalone",
    "diamonds": "diamonds",
}


def environment_versions() -> dict[str, str | None]:
    """Record all libraries that can affect feature generation or model fitting."""
    names = (
        "featcopilot",
        "numpy",
        "pandas",
        "scipy",
        "scikit-learn",
        "lightgbm",
        "catboost",
        "xgboost",
        "openfe",
        "autofeat",
        "openml",
        "psutil",
        "joblib",
        "threadpoolctl",
        "pydantic",
        "sympy",
        "numba",
    )
    versions: dict[str, str | None] = {}
    for name in names:
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return versions


def _load_suite(path: Path, allow_confirmation: bool) -> tuple[dict, bool]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    legacy = (
        "revision" in raw
        and "schema_version" not in raw
        and all("provider" not in row for row in raw.get("datasets", []))
    )
    if legacy:
        if not isinstance(raw["revision"], str) or not re.fullmatch(r"[0-9a-fA-F]{40}", raw["revision"]):
            raise ValueError("Legacy replay requires an immutable 40-character source revision")
        for spec in raw["datasets"]:
            spec.setdefault("family_id", LEGACY_FAMILIES.get(spec["name"], spec["name"]))
            spec.setdefault("role", "development")
            spec["rights_status"] = "legacy-not-reviewed"
        return raw, True
    from benchmarks.catalog import load_suite

    return load_suite(path, allow_confirmation=allow_confirmation), False


def _prepare_dataset(spec: dict, source: str, suite: dict, legacy: bool, config: dict, root: Path):
    from benchmarks import tabular

    groups, timestamps, official_splits = None, None, None
    if spec.get("provider") == "diagnostic":
        from benchmarks.datasets import load_dataset

        X, y, _, _ = load_dataset(spec["name"])
        metadata = {
            **spec,
            "source": source,
            "sampled_rows": len(X),
            "sha256": tabular.digest(pd.util.hash_pandas_object(pd.concat([X, y], axis=1)).to_numpy().tobytes()),
        }
    elif legacy or "_legacy_revision" in spec:
        revision = spec.get("_legacy_revision", suite.get("revision"))
        if not isinstance(revision, str) or not re.fullmatch(r"[0-9a-fA-F]{40}", revision):
            raise ValueError("Legacy replay requires an immutable source revision")
        cached = root / "benchmarks" / ".cache" / revision / Path(spec["path"])
        if not cached.exists():
            raise ValueError(
                "Legacy manifests support local cached-data replay only; use a rights-reviewed catalog manifest for acquisition"
            )
        X, y, metadata = tabular.load_real_dataset(spec, revision, root / "benchmarks" / ".cache", config["max_rows"])
    else:
        from benchmarks.catalog import load_dataset as load_catalog_dataset

        loaded = load_catalog_dataset(
            spec, root / "benchmarks" / ".cache", max_rows=config["max_rows"], sample_seed=2026
        )
        X, y, metadata = loaded.X, loaded.y, loaded.metadata
        groups, timestamps, official_splits = loaded.groups, loaded.timestamps, loaded.official_splits
    X = X.reset_index(drop=True)
    y = pd.Series(np.asarray(y), name="target")
    if spec["task"] == "classification":
        encoder = LabelEncoder()
        y = pd.Series(encoder.fit_transform(y), name="target")
        metadata = {**metadata, "evaluation_classes": [str(value) for value in encoder.classes_]}
    for name, values in (("groups", groups), ("timestamps", timestamps)):
        if values is not None and len(values) != len(X):
            raise ValueError(f"{name} must have one value per dataset row")
    groups = None if groups is None else pd.Series(np.asarray(groups), index=X.index)
    timestamps = None if timestamps is None else pd.Series(np.asarray(timestamps), index=X.index)
    metadata = {
        **metadata,
        "family_id": spec.get("family_id", spec["name"]),
        "role": spec.get("role", "development"),
        "source": source,
    }
    return {"X": X, "y": y, "groups": groups, "timestamps": timestamps}, metadata, official_splits


def _splits(data: dict, task: str, config: dict, official_splits) -> list[tuple[int, int, np.ndarray, np.ndarray]]:
    from featcopilot.utils.splitting import make_cv_splits

    results = []
    for seed in config["seeds"]:
        pairs = official_splits
        if pairs is None:
            pairs = make_cv_splits(
                data["y"].to_numpy(),
                task,
                config["folds"],
                seed,
                groups=None if data["groups"] is None else data["groups"].to_numpy(),
                timestamps=None if data["timestamps"] is None else data["timestamps"].to_numpy(),
            )
            if len(pairs) != config["folds"]:
                raise ValueError(
                    f"Requested {config['folds']} outer folds but only {len(pairs)} are feasible; "
                    "choose a feasible fold count explicitly"
                )
        for fold, (train, test) in enumerate(pairs):
            train, test = np.asarray(train), np.asarray(test)
            if train.dtype.kind not in "iu" or test.dtype.kind not in "iu" or train.ndim != 1 or test.ndim != 1:
                raise ValueError("Outer split indices must be one-dimensional integer arrays")
            if not len(train) or not len(test) or np.intersect1d(train, test).size:
                raise ValueError("Outer splits must be nonempty and disjoint")
            if np.unique(train).size != train.size or np.unique(test).size != test.size:
                raise ValueError("Outer splits cannot contain duplicated row positions")
            if min(train.min(), test.min()) < 0 or max(train.max(), test.max()) >= len(data["X"]):
                raise ValueError("Outer split indices are outside the prepared dataset")
            results.append((seed, fold, train, test))
    return results


def split_fingerprint(train: np.ndarray, test: np.ndarray) -> str:
    """Fingerprint ordered indices including the train/test boundary."""
    from benchmarks.tabular import digest

    lengths = np.asarray([len(train), len(test)], dtype="<i8").tobytes()
    return digest(lengths + train.astype("<i8").tobytes() + test.astype("<i8").tobytes())


def source_kind(spec: dict) -> str:
    """Normalize declared data origin without losing simulation distinctions."""
    kind = spec.get("origin_kind", "observational")
    mapping = {
        "observational": "real_world",
        "real_world": "real_world",
        "simulation": "simulation",
        "domain_simulation": "simulation",
        "synthetic": "synthetic",
        "synthetic_diagnostic": "synthetic",
    }
    if not isinstance(kind, str) or kind not in mapping:
        raise ValueError(f"Unknown dataset origin_kind: {kind!r}")
    return mapping[kind]


def execute(args) -> int:
    """Run new cells or resume fingerprint-identical cells from an existing run."""
    from benchmarks import tabular

    output = args.output.resolve()
    previous = {}
    if args.resume:
        previous = json.loads((output / "manifest.json").read_text(encoding="utf-8"))
        if previous.get("source_changed"):
            raise ValueError("Cannot resume a run invalidated by source changes")
    old_config = previous.get("config", {})
    defaults = {
        **DEFAULTS,
        "methods": list(tabular.METHODS),
        "learners": list(tabular.LEARNERS),
        "suite": str(tabular.SUITE_PATH),
    }
    config: dict[str, Any] = {
        key: getattr(args, key, None) if getattr(args, key, None) is not None else old_config.get(key, default)
        for key, default in defaults.items()
    }
    suite_paths = config["suite"] if isinstance(config["suite"], list) else [config["suite"]]
    config["suite"] = [str(Path(path).resolve()) for path in suite_paths]
    budget = args.total_seconds if args.total_seconds is not None else previous.get("budget_seconds", 14400.0)
    validate_config(config, budget)
    suites, specs = [], []
    for path in config["suite"]:
        loaded_suite, is_legacy = _load_suite(Path(path), config["allow_confirmation"])
        suites.append(loaded_suite)
        for spec in loaded_suite["datasets"]:
            specs.append({**spec, "_legacy_revision": loaded_suite["revision"]} if is_legacy else spec)
    suite = {"name": "+".join(item["name"] for item in suites), "manifests": suites, "datasets": specs}
    legacy = False
    if not specs or any(
        not isinstance(spec.get("name"), str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", spec["name"])
        for spec in specs
    ):
        raise ValueError("Suite datasets must have nonempty, path-safe identifiers")
    if config["datasets"]:
        unknown = set(config["datasets"]) - {spec["name"] for spec in specs}
        if unknown:
            raise ValueError(f"Unknown datasets: {sorted(unknown)}")
        specs = [spec for spec in specs if spec["name"] in config["datasets"]]
    if len({spec["name"] for spec in specs}) != len(specs):
        raise ValueError("Combined suites contain duplicated dataset identifiers")
    if len({spec.get("family_id", spec["name"]) for spec in specs}) != len(specs):
        raise ValueError("Combined primary suites contain repeated origin families; run variants separately")
    if args.list_datasets:
        for spec in specs:
            logger.info(
                "%s: family=%s task=%s role=%s provider=%s rights=%s",
                spec["name"],
                spec.get("family_id"),
                spec["task"],
                spec.get("role"),
                spec.get("provider", "legacy-hf"),
                spec.get("rights", spec.get("rights_status")),
            )
        return 0
    identity = {
        "protocol_version": tabular.PROTOCOL_VERSION,
        "source_sha256": tabular.source_fingerprint(),
        "suite": suite,
        "config": config,
        "versions": environment_versions(),
        "python": sys.version,
        "platform": platform.platform(),
    }
    state = RunState(output, identity, resume=args.resume)
    if args.resume:
        if tabular.digest((output / "source.zip").read_bytes()) != previous["source_archive_sha256"]:
            raise ResumeMismatchError("Cannot resume: source archive changed")
        source_archive_hash = previous["source_archive_sha256"]
    else:
        source_archive_hash = archive_source(output, tabular.ROOT, tabular.source_files(), suite)
    started = time.perf_counter()
    prior_elapsed = state.elapsed_seconds
    deadline = started + max(0.0, budget - prior_elapsed)
    manifest = {
        **previous,
        "protocol_version": tabular.PROTOCOL_VERSION,
        "run_id": state.run_id,
        "suite": suite,
        "config": config,
        "budget_seconds": budget,
        "started_utc": previous.get("started_utc", datetime.now(timezone.utc).isoformat()),
        "versions": identity["versions"],
        "python": identity["python"],
        "platform": identity["platform"],
        "source_sha256": identity["source_sha256"],
        "source_archive_sha256": source_archive_hash,
        "datasets": [],
        "splits": [],
        "resumed": bool(args.resume),
        "evaluation_unit": "dataset-split-method-learner",
    }
    if not args.resume:
        atomic_json(output / "manifest.json", manifest)
    ledger = ExposureLedger(tabular.ROOT / "benchmarks" / ".cache" / "exposure.sqlite")
    requested = [(spec, source_kind(spec)) for spec in specs]
    if config["synthetic"]:
        requested.extend(
            (
                {
                    "name": name,
                    "family_id": f"synthetic:{name}",
                    "role": "development",
                    "task": task,
                    "provider": "diagnostic",
                },
                "synthetic",
            )
            for name, task in (("polynomial_regression", "regression"), ("xor_classification", "classification"))
        )
    jobs = []
    prepared_dir = output / "prepared"
    prepared_dir.mkdir(exist_ok=True)
    for spec, source in requested:
        name = spec["name"]
        error = None
        splits: list[tuple[int, int, np.ndarray | None, np.ndarray | None]]
        logger.info("Preparing %s", name)
        try:
            if time.perf_counter() >= deadline:
                raise TimeoutError("Experiment budget exhausted before preparation")
            data, metadata, official = _prepare_dataset(spec, source, suite, legacy, config, tabular.ROOT)
            splits = [
                (seed, fold, train, test) for seed, fold, train, test in _splits(data, spec["task"], config, official)
            ]
            metadata["outer_split_count"] = len(splits)
            state.validate_dataset(name, metadata)
            if not args.prepare_only:
                ledger.admit(spec.get("family_id", name), state.run_id, spec.get("role", "development"))
            data_path = prepared_dir / f"{name}.pkl"
            prepared_bytes = pickle.dumps(data)
            data_path.write_bytes(prepared_bytes)
            prepared_sha256 = tabular.digest(prepared_bytes)
        except ResumeMismatchError:
            raise
        except Exception as exc:
            logger.exception("Dataset preparation failed for %s", name)
            error = f"{type(exc).__name__}: {exc}"
            metadata = {**spec, "source": source, "error": error}
            data_path = None
            prepared_sha256 = None
            splits = [(seed, fold, None, None) for seed in config["seeds"] for fold in range(config["folds"])]
        manifest["datasets"].append(metadata)
        for seed, fold, train, test in splits:
            split_hash = split_fingerprint(train, test) if train is not None and test is not None else "unavailable"
            manifest["splits"].append({"dataset": name, "seed": seed, "fold": fold, "sha256": split_hash})
            for method in config["methods"]:
                for learner in config["learners"]:
                    cell_id = state.cell_id(name, seed, fold, method, learner)
                    cell_hash = fingerprint(
                        {"identity": state.identity_hash, "data": metadata, "split": split_hash, "cell": cell_id}
                    )
                    payload = {
                        "data_path": None if data_path is None else str(data_path),
                        "prepared_sha256": prepared_sha256,
                        "dataset": name,
                        "family_id": spec.get("family_id", name),
                        "role": spec.get("role", "development"),
                        "source": metadata.get("source", source),
                        "task": spec["task"],
                        "method": method,
                        "seed": seed,
                        "fold": fold,
                        "train_idx": train,
                        "test_idx": test,
                        "split_sha256": split_hash,
                        "expected_cells": len(splits),
                        "config": {**config, "learners": [learner], "seed": seed},
                    }
                    jobs.append((cell_id, cell_hash, payload, error))
    # Spread early coverage across datasets rather than exhausting one dataset first.
    jobs.sort(key=lambda job: (job[2]["fold"], job[2]["seed"], fingerprint(job[0])))
    manifest["planned_cells"] = len(jobs)
    interrupted = False
    source_changed = False
    for cell_id, cell_hash, payload, error in jobs:
        if args.prepare_only:
            break
        if state.reusable(cell_id, cell_hash, retry_failed=args.retry_failed):
            continue
        remaining = deadline - time.perf_counter()
        if not source_changed and tabular.source_fingerprint() != manifest["source_sha256"]:
            source_changed = True
            manifest["source_changed"] = True
        if error is not None:
            row = tabular.failure_rows(payload, "dataset_error", error, 0.0)[0]
        elif source_changed:
            row = tabular.failure_rows(payload, "source_changed", "Source code changed during the experiment", 0.0)[0]
        elif interrupted or remaining <= 0:
            row = tabular.failure_rows(
                payload,
                "interrupted" if interrupted else "budget_exhausted",
                "Experiment interrupted" if interrupted else "Experiment active-time budget exhausted",
                0.0,
            )[0]
        else:
            logger.info(
                "%s seed=%s fold=%s %s/%s",
                payload["dataset"],
                payload["seed"],
                payload["fold"],
                payload["method"],
                payload["config"]["learners"][0],
            )
            directory = state.next_attempt(cell_id)
            try:
                result = tabular.run_isolated(payload, directory, min(config["case_timeout"], remaining))
                if len(result) != 1:
                    raise ValueError("An isolated evaluation cell must return exactly one learner result")
                row = result[0]
            except KeyboardInterrupt:
                interrupted = True
                row = tabular.failure_rows(payload, "interrupted", "Experiment interrupted", 0.0)[0]
            row["log"] = str((directory / "worker.log").relative_to(output))
            if tabular.source_fingerprint() != manifest["source_sha256"]:
                source_changed = True
                manifest["source_changed"] = True
        state.elapsed_seconds = prior_elapsed + time.perf_counter() - started
        state.record(cell_id, cell_hash, row)
        manifest["active_seconds"] = state.elapsed_seconds
        atomic_json(output / "manifest.json", manifest)
        tabular.write_report(output, manifest, list(state.rows.values()))
    state.elapsed_seconds = prior_elapsed + time.perf_counter() - started
    state.save()
    manifest["active_seconds"] = state.elapsed_seconds
    manifest["finished_utc"] = datetime.now(timezone.utc).isoformat()
    manifest["source_sha256_at_finish"] = tabular.source_fingerprint()
    manifest["source_changed"] = source_changed or manifest["source_sha256_at_finish"] != manifest["source_sha256"]
    atomic_json(output / "manifest.json", manifest)
    if not args.prepare_only:
        tabular.write_report(output, manifest, list(state.rows.values()))
        archive_results(output / "results.json")
    logger.info("Saved %s: %d/%d evaluation cells", output, len(state.rows), len(jobs))
    return (
        0
        if not manifest["source_changed"]
        and all(row["status"] == "success" for row in state.rows.values())
        and all("error" not in item for item in manifest["datasets"])
        else 1
    )


def validate_config(config: dict, budget: float) -> None:
    """Reject invalid experiment controls before creating output state."""
    if config["folds"] < 2 or config["threads"] < 1 or config["max_rows"] < 0:
        raise ValueError("folds >= 2, threads >= 1 and max_rows >= 0 are required")
    if (
        min(
            config["max_added_features"],
            config["max_candidates"],
            config["stability_repeats"],
            config["memory_limit_mb"],
        )
        < 1
    ):
        raise ValueError("Feature, repeat and memory limits must be positive")
    if not np.isfinite([budget, config["case_timeout"]]).all() or min(budget, config["case_timeout"]) <= 0:
        raise ValueError("Time limits must be finite and positive")
    for key in ("methods", "learners", "seeds"):
        if not config[key] or len(config[key]) != len(set(config[key])):
            raise ValueError(f"{key} must be nonempty and unique")
    if "baseline" not in config["methods"]:
        raise ValueError("A paired baseline is required")
    if any(not 0 <= seed < 2**32 for seed in config["seeds"]):
        raise ValueError("Seeds must be in [0, 2**32)")
