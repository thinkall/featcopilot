"""Shared positional IID, grouped and forward-only supervised split boundaries."""

from dataclasses import dataclass
from numbers import Integral, Real
from typing import Literal

import numpy as np
import pandas as pd
from numpy.typing import ArrayLike
from sklearn.model_selection import GroupKFold, GroupShuffleSplit, KFold, StratifiedKFold, train_test_split

from featcopilot.utils.task import resolve_task


@dataclass(frozen=True)
class SplitMetadata:
    """
    Validated positional entity or chronological block identifiers.

    Parameters
    ----------
    kind : {'iid', 'grouped', 'temporal'}, default='iid'
        Split protocol.
    values : ndarray or None, default=None
        Integer entity identifiers or chronologically ordered time-block codes.
        Construct these with ``validate_split_metadata`` rather than manually.
    """

    kind: Literal["iid", "grouped", "temporal"] = "iid"
    values: np.ndarray | None = None

    @property
    def groups(self) -> np.ndarray | None:
        """Get entity identifiers for the public split helpers."""
        return self.values if self.kind == "grouped" else None

    @property
    def timestamps(self) -> np.ndarray | None:
        """Get ordered time-block identifiers for the public split helpers."""
        return self.values if self.kind == "temporal" else None

    def subset(self, indices: np.ndarray) -> "SplitMetadata":
        """Subset by row position without changing the protocol."""
        return SplitMetadata(self.kind, None if self.values is None else self.values[indices])


def validate_split_metadata(groups: ArrayLike | None, timestamps: ArrayLike | None, n_rows: int) -> SplitMetadata:
    """
    Normalize split metadata without aligning pandas index labels.

    Parameters
    ----------
    groups : array-like or None
        One scalar, hashable entity identifier per row.
    timestamps : array-like or None
        One finite numeric or parseable datetime timestamp per row. Datetimes
        normalize to UTC; equal instants form one indivisible block.
    n_rows : int
        Expected positional length.

    Returns
    -------
    SplitMetadata
        Entity codes or chronologically ordered time-block codes.

    Raises
    ------
    ValueError
        For missing, malformed or mis-sized metadata, or simultaneous groups
        and timestamps. Joint group/temporal splitting is not implemented.
    """
    if isinstance(n_rows, bool) or not isinstance(n_rows, Integral) or n_rows < 0:
        raise ValueError("n_rows must be a nonnegative integer")
    if groups is not None and timestamps is not None:
        raise ValueError("groups and timestamps together are not supported; choose one explicit split boundary")
    if groups is None and timestamps is None:
        return SplitMetadata()
    name = "groups" if groups is not None else "timestamps"
    values = np.asarray(groups if groups is not None else timestamps)
    if values.ndim != 1 or len(values) != n_rows:
        raise ValueError(f"{name} must be one-dimensional and contain the same number of rows as the data")
    if pd.isna(values).any():
        raise ValueError(f"{name} must not contain missing values")
    if groups is not None:
        try:
            codes, _ = pd.factorize(values, sort=False)
        except (TypeError, ValueError) as exc:
            raise ValueError("groups must contain scalar, hashable entity labels") from exc
        return SplitMetadata("grouped", np.asarray(codes))
    inferred = pd.Series(values).infer_objects()
    if pd.api.types.is_numeric_dtype(inferred.dtype):
        if pd.api.types.is_complex_dtype(inferred.dtype) or not np.isfinite(inferred.to_numpy()).all():
            raise ValueError("timestamps must contain finite real numeric values or valid datetimes")
        ordered = inferred.to_numpy()
    else:
        try:
            parsed = pd.to_datetime(inferred, errors="raise", utc=True)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("timestamps must contain finite numeric values or valid datetimes") from exc
        if parsed.isna().any():
            raise ValueError("timestamps must not contain missing values")
        ordered = parsed.array.asi8
    codes, _ = pd.factorize(ordered, sort=True)
    return SplitMetadata("temporal", np.asarray(codes))


def make_cv_splits(
    y: ArrayLike,
    task: str,
    n_splits: int,
    random_state: int,
    *,
    groups: ArrayLike | None = None,
    timestamps: ArrayLike | None = None,
) -> list[tuple[np.ndarray, np.ndarray]]:
    """
    Build deterministic CV boundaries without entity or future-data overlap.

    Parameters
    ----------
    y : array-like
        One-dimensional, nonconstant supervised target.
    task : {'auto', 'classification', 'regression'}
        Explicit task or sklearn-compatible target inference.
    n_splits : int
        Requested maximum number of folds, at least two. Classification/group
        folds are capped by the smallest class count/number of groups. Temporal
        folds are capped by the available future blocks and may number one.
        Callers requiring an exact protocol count must check the returned length.
    random_state : int
        Nonnegative uint32 seed for IID folds. Group and temporal folds are
        deterministic; their partitions do not depend on the seed.
    groups : array-like or None, default=None
        Positionally aligned entity labels; every fold keeps groups disjoint.
    timestamps : array-like or None, default=None
        Positionally aligned timestamps, mutually exclusive with groups.

    Returns
    -------
    list of (ndarray, ndarray)
        Training/validation integer row positions. IID/group validation folds
        cover all rows once. Temporal CV leaves an initial historical prefix
        unscored and partitions the remaining time blocks into disjoint windows.

    Raises
    ------
    ValueError
        For invalid options/metadata or infeasible supervised partitions.

    Notes
    -----
    Temporal CV reserves the first half of the time blocks for initial training,
    with a minimum of two blocks for two requested folds and four otherwise.
    Subsequent training prefixes expand strictly before each validation window.
    There is no random fallback. This preserves the predictive engine's nested
    residual-split policy; these are not official provider-specific task folds.
    """
    _validate_options(n_splits, random_state, minimum=2)
    target, resolved_task = _validate_target(y, task)
    metadata = validate_split_metadata(groups, timestamps, len(target))
    values = metadata.values
    if metadata.kind == "temporal" and values is not None:
        blocks = np.unique(values)
        first = max(2 if n_splits == 2 else 4, (len(blocks) + 1) // 2)
        available = len(blocks) - first
        if available < 1:
            raise ValueError("Too few time blocks for forward cross-validation; provide more history")
        partitions = _temporal_partitions(values, list(np.array_split(blocks[first:], min(n_splits, available))))
    elif metadata.kind == "grouped" and values is not None:
        count = min(n_splits, len(np.unique(values)))
        if count < 2:
            raise ValueError("Too few groups for cross-validation")
        partitions = list(GroupKFold(n_splits=count).split(np.arange(len(target)), target, groups=values))
    elif resolved_task == "classification":
        count = min(n_splits, int(pd.Series(target).value_counts().min()))
        if count < 2:
            raise ValueError(
                "Classification CV requires at least two samples per class; provide more samples per class"
            )
        partitions = list(
            StratifiedKFold(n_splits=count, shuffle=True, random_state=random_state).split(target, target)
        )
    else:
        if len(target) < n_splits:
            raise ValueError("Too few samples for the requested cross-validation folds")
        partitions = list(KFold(n_splits=n_splits, shuffle=True, random_state=random_state).split(target))
    _check_partitions(target, resolved_task, partitions, metadata, "Cross-validation")
    return partitions


def make_holdout_splits(
    y: ArrayLike,
    task: str,
    n_splits: int,
    random_state: int,
    *,
    test_size: float = 0.25,
    groups: ArrayLike | None = None,
    timestamps: ArrayLike | None = None,
) -> list[tuple[np.ndarray, np.ndarray]]:
    """
    Build repeated IID/group holdouts or disjoint forward validation windows.

    Parameters
    ----------
    y : array-like
        One-dimensional, nonconstant supervised target.
    task : {'auto', 'classification', 'regression'}
        Explicit task or sklearn-compatible target inference.
    n_splits : int
        Exact number of holdouts, at least one.
    random_state : int
        Seed for the first IID/group holdout. Subsequent seeds increment modulo
        2**32. Temporal boundaries do not depend on random state.
    test_size : float, default=0.25
        Validation fraction in (0, 1), measured in IID rows or whole groups.
        For time blocks this is the approximate fraction of the first
        train-plus-validation prefix occupied by its validation window.
    groups : array-like or None, default=None
        Positionally aligned entity labels.
    timestamps : array-like or None, default=None
        Positionally aligned timestamps, mutually exclusive with groups.

    Returns
    -------
    list of (ndarray, ndarray)
        Training/validation row positions. Temporal windows have equal numbers
        of complete time blocks, cover the final blocks without overlap, and
        have expanding strictly earlier training prefixes.

    Raises
    ------
    ValueError
        For invalid options/metadata or infeasible supervised partitions.

    Notes
    -----
    Temporal window width is floor(B * test_size /
    (1 + (n_splits - 1) * test_size)), at least one block, where B is the
    number of distinct time blocks. Rounding can change the achieved fraction.
    At least four blocks and a two-block initial prefix are required.
    Repeated random holdouts may overlap; none is an unbiased external test
    once used for feature/hyperparameter selection.
    """
    _validate_options(n_splits, random_state, minimum=1)
    if (
        isinstance(test_size, bool)
        or not isinstance(test_size, Real)
        or not np.isfinite(test_size)
        or not 0 < test_size < 1
    ):
        raise ValueError("test_size must be a finite fraction strictly between zero and one")
    target, resolved_task = _validate_target(y, task)
    metadata = validate_split_metadata(groups, timestamps, len(target))
    values = metadata.values
    partitions: list[tuple[np.ndarray, np.ndarray]] = []
    if metadata.kind == "temporal" and values is not None:
        blocks = np.unique(values)
        if len(blocks) < 4:
            raise ValueError("Temporal holdouts need at least four distinct time blocks")
        width = max(1, int(len(blocks) * test_size / (1 + (n_splits - 1) * test_size)))
        first = len(blocks) - n_splits * width
        if first < 2:
            raise ValueError("Too few time blocks for the requested holdouts and a two-block historical prefix")
        windows = [blocks[first + repeat * width : first + (repeat + 1) * width] for repeat in range(n_splits)]
        partitions = _temporal_partitions(values, windows)
    else:
        for repeat in range(n_splits):
            seed = (int(random_state) + repeat) % (2**32)
            if metadata.kind == "grouped" and values is not None:
                if len(np.unique(values)) < 2:
                    raise ValueError("Grouped holdouts require at least two distinct groups")
                splitter = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=seed)
                try:
                    train, validation = next(splitter.split(np.arange(len(target)), target, groups=values))
                except ValueError as exc:
                    raise ValueError(f"Cannot create the grouped holdout split: {exc}") from exc
            else:
                try:
                    train, validation = train_test_split(
                        np.arange(len(target)),
                        test_size=test_size,
                        random_state=seed,
                        stratify=target if resolved_task == "classification" else None,
                    )
                except ValueError as exc:
                    raise ValueError(f"Cannot create the internal holdout split: {exc}") from exc
            partitions.append((np.asarray(train), np.asarray(validation)))
    _check_partitions(target, resolved_task, partitions, metadata, "Holdout")
    return partitions


def _validate_options(n_splits: int, random_state: int, minimum: int) -> None:
    if isinstance(n_splits, bool) or not isinstance(n_splits, Integral) or n_splits < minimum:
        raise ValueError(f"n_splits must be an integer of at least {minimum}")
    if (
        isinstance(random_state, bool)
        or not isinstance(random_state, Integral)
        or random_state < 0
        or random_state >= 2**32
    ):
        raise ValueError("random_state must be an integer between zero and 2**32 - 1")


def _validate_target(y: ArrayLike, task: str) -> tuple[np.ndarray, str]:
    target = np.asarray(y)
    resolved_task = resolve_task(target, task)
    target = pd.Series(target).infer_objects().to_numpy()
    if pd.api.types.is_numeric_dtype(target.dtype) and not np.isfinite(target).all():
        raise ValueError("Target y must contain finite values")
    if pd.Series(target).nunique() < 2:
        raise ValueError("Target y must not be constant for supervised splitting")
    return target, resolved_task


def _temporal_partitions(values: np.ndarray, windows: list[np.ndarray]) -> list[tuple[np.ndarray, np.ndarray]]:
    return [(np.flatnonzero(values < window[0]), np.flatnonzero(np.isin(values, window))) for window in windows]


def _check_partitions(
    target: np.ndarray,
    task: str,
    partitions: list[tuple[np.ndarray, np.ndarray]],
    metadata: SplitMetadata,
    context: str,
) -> None:
    for train, validation in partitions:
        if not len(train) or not len(validation) or np.intersect1d(train, validation).size:
            raise ValueError(f"{context} requires nonempty, disjoint training and validation rows")
        if task == "classification" and set(target[train]) != set(target):
            raise ValueError(f"{context} training split must contain every class; provide more samples per class")
        if len(train) < 2 or pd.Series(target[train]).nunique() < 2:
            raise ValueError(f"{context} training split has a constant target or fewer than two samples")
        values = metadata.values
        if values is not None and metadata.kind == "grouped":
            if np.intersect1d(values[train], values[validation]).size:
                raise ValueError(f"{context} must not place the same group in training and validation")
        if values is not None and metadata.kind == "temporal":
            if values[train].max() >= values[validation].min():
                raise ValueError(f"{context} requires a strictly earlier training prefix without shared time blocks")
